create function st_approxquantile(rast raster, sample_percent double precision, quantiles double precision[] DEFAULT NULL::double precision[], OUT quantile double precision, OUT value double precision) returns SETOF record
    immutable
    parallel safe
    language sql
as
$$
SELECT public._ST_quantile($1, 1, TRUE, $2, $3)
$$;

alter function st_approxquantile(raster, double precision, double precision[], out double precision, out double precision) owner to postgres;

