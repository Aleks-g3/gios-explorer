create function st_mpointfromtext(text) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromText($1)) = 'MULTIPOINT'
	THEN public.ST_GeomFromText($1)
	ELSE NULL END

$$;

comment on function st_mpointfromtext(text) is 'args: WKT - Makes a Geometry from WKT with the given SRID. If SRID is not given, it defaults to 0.';

alter function st_mpointfromtext(text) owner to postgres;

