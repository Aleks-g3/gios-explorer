create function st_multipolygonfromtext(text, integer) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_MPolyFromText($1, $2)
$$;

alter function st_multipolygonfromtext(text, integer) owner to postgres;

