create function postgis_raster_scripts_installed() returns text
    immutable
    parallel safe
    language sql
as
$$
SELECT '2.5.3'::text || ' r' || 0::text AS version
$$;

alter function postgis_raster_scripts_installed() owner to postgres;

