create view pm10_prediction_comparison (real_timestamp, prediction_timestamp, station, real_value, predicted_value) as
SELECT ed."timestamp" AS real_timestamp,
       p."timestamp"  AS prediction_timestamp,
       ed.station,
       ed.pm10        AS real_value,
       p.value        AS predicted_value
FROM enriched_data ed
         JOIN prediction p ON ed.station::text = p.stationid::text AND
                              (p."timestamp" + '23:00:00'::interval hour) <= ed."timestamp" AND
                              ed."timestamp" <= (p."timestamp" + '24:00:00'::interval hour)
ORDER BY p."timestamp" DESC;

alter table pm10_prediction_comparison
    owner to postgres;

